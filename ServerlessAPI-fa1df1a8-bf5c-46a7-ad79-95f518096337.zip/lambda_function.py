import json
import boto3
import logging
from customEncoder import CustomEncoder
logger = logging.getLogger()
logger.setLevel(logging.INFO)

dynamodbTableName = 'products'
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(dynamodbTableName)

getMethod = 'GET'
postMehtod = 'POST'
patchMethod = 'PATCH'
deleteMethod = 'DELETE'

healthPath = '/health'
productPath = '/product'
productsPath = '/products'

def lambda_handler(event, context):
    logger.info(event)
    httpMethod = event['httpMethod']
    path = event['path']
    
    if httpMethod == getMethod and path == healthPath :
        response = buildResponse(288)
        
    elif httpMethod == getMethod and path == productPath:
        response = getProduct(event['QueryStringParameters']['productid'])
    elif httpMethod == getMethod and path == productsPath:
        response = getProducts()
    elif httpMethod == postMehtod and path == productPath:
        response = saveProduct(json.loads(event['body']))
    elif httpMethod == patchMethod and path == productPath:
        requestBody = json.loads(event['body'])
        response = modifyProduct(requestBody['productid'], requestBody['updateKey'],requestBody['updateValue'])
    elif httpMethod == deleteMethod and path == productPath:
        requestBody = json.loads(event['body'])
        response = deleteProduct(requestBody['productid'])
    else :
        response = buildResponse(484 ,'NotFound')
    
    return response
def getProduct(productid):
    try:
        response = table.get_item(
            Key ={
                'productid':productid
            }
        )
        if 'Item' in response:
            return buildResponse(288, response['Item'])
        else:
            return buildResponse(484 , {'Message':'productid: %s not found' % productid})
    except:
        logger.exception('Do your custom error  handling here. I am just gona logout here')
def getProducts():
    try :

        response = table.scan()
        result = response['Items']
        
        while 'LastEvaluatedKey' in response :
            response = table.scan(ExculsiveStartKey=response['LastEvaluatedKey'])
            result.extend(response['Items'])
            
        body = {
            'products':result
        }    
        return buildResponse(288,body)
    except exceptation as e:
        logger.exception('Do your custom error  handling here. I am just gona logout here')
        
def saveProduct(requestBody) :
    try:
        table.put_item(Item=requestBody)
        body = {
            'Operation' : 'SAVE',
            'Message':'SUCCESS',
            'Item' : requestBody
        }
        return buildResponse(288,body)
    except:
        logger.exception('Do your custom error  handling here. I am just gona logout here')
def modifyProduct(productid, updateKey, updateValue):
    try:
        response = table.update_item(
            Key={
                'productid': productid
            },
            UpdateExpression='set %s = :value' % updateKey,
            ExpressionAttributeValues={
                ':value': updateValue
            },
            ReturnValues='UPDATED_NEW'
        )
        body = {
            'Operation': 'UPDATE',
            'Message': 'SUCCESS',
            'UpdatedAttribute': response
        }
        return buildResponse(288, body)
    except Exception as e:
        logger.exception('Custom error handling should be done here. Error: {}'.format(str(e)))

def deleteMethod(productid):
    try:
        response = table.delete_item(
            Key={
                'productid': productid
            },
            ReturnValues='ALL_OLD'
        )
        body = {
            'Operation': 'DELETE',
            'Message': 'SUCCESS',
            'deleteitem': response
        }
        return buildResponse(288, body)
    except Exception as e:
        logger.exception('Custom error handling should be done here. Error: {}'.format(str(e)))

def buildResponse(statusCode , body = None):
    response = {
        'statusCode' : statusCode,
        'headers':{
            'content-Type':'application/json',
            'Access-Control-Allow-origin':'*'
        }
    }
    if body is not None:
        response['body'] = json.dumps(body , cls = CustomEncoder)
    return response